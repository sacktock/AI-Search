Solution files for the AI search summative 2019/2020

- *All* .py files should run fine from the command line or the IDLE on python 3.5 or higher
- *Important* imported modules include: os, sys, time, random, copy, heapq, math and numpy.
